import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")

ADMIN_IDS = [
    int(x) for x in os.getenv("ADMIN_IDS", "").replace(" ", "").split(",") if x
]

PAYMENTS_CHAT_ID = int(os.getenv("PAYMENTS_CHAT_ID", ADMIN_IDS[0] if ADMIN_IDS else 0))

CARD_NUMBER = os.getenv("CARD_NUMBER", "2204 1201 3543 0268")
CARD_HOLDER = os.getenv("CARD_HOLDER", "")
CARD_BANK = os.getenv("CARD_BANK", "")

CRYPTOBOT_TOKEN = os.getenv("CRYPTOBOT_TOKEN", "")

REVIEWS_LINK = os.getenv("REVIEWS_LINK", "https://t.me/")

BOT_USERNAME = os.getenv("BOT_USERNAME", "")  # без @, если пусто - определится сам через getMe()
SUPPORT_BOT_USERNAME = os.getenv("SUPPORT_BOT_USERNAME", "")  # без @

REFERRAL_PERCENT = int(os.getenv("REFERRAL_PERCENT", "30"))
MIN_REFERRALS_FOR_PAYOUT = int(os.getenv("MIN_REFERRALS_FOR_PAYOUT", "10"))

DB_PATH = os.getenv("DB_PATH", "shop.db")

# ---------------------------------------------------------------------------
# Товары. На старте храним прямо тут списком (позже — вынесем в БД / админку).
# price_rub   — цена в рублях (для карты и как база для конвертации в крипту)
# price_stars — цена в Telegram Stars
# price_usdt  — цена в USDT (CryptoBot)
# delivery    — текст/содержимое, которое уйдёт покупателю после подтверждения
# ---------------------------------------------------------------------------
PRODUCTS = [
    {
        "id": "key_7d",
        "title": "Приватный ключ — 7 дней",
        "price_rub": 500,
        "price_usdt": 5,
        "delivery": "Ваш ключ: DEMO-7D-XXXX-XXXX\nСрок действия: 7 дней.",
    },
    {
        "id": "key_30d",
        "title": "Приватный ключ — 30 дней",
        "price_rub": 1500,
        "price_usdt": 15,
        "delivery": "Ваш ключ: DEMO-30D-XXXX-XXXX\nСрок действия: 30 дней.",
    },
    {
        "id": "key_60d",
        "title": "Приватный ключ — 60 дней",
        "price_rub": 2500,
        "price_usdt": 25,
        "delivery": "Ваш ключ: DEMO-60D-XXXX-XXXX\nСрок действия: 60 дней.",
    },
    {
        "id": "key_lifetime",
        "title": "Приватный ключ — Навсегда",
        "price_rub": 4000,
        "price_usdt": 40,
        "delivery": "Ваш ключ: DEMO-LIFE-XXXX-XXXX\nСрок действия: бессрочно.",
    },
]

FAQ_TEXT = (
    "❓ <b>FAQ</b>\n\n"
    "<b>Как работает ключ?</b>\n"
    "После оплаты вы получаете уникальный ключ в этом чате.\n\n"
    "<b>Способы оплаты?</b>\n"
    "Telegram Stars, криптовалюта (CryptoBot) и банковская карта.\n\n"
    "<b>Сколько ждать подтверждения при оплате картой?</b>\n"
    "Обычно до 15 минут после того, как вы пришлёте чек.\n\n"
    "<b>Есть гарантия?</b>\n"
    "Да, при проблемах с ключом пишите в поддержку."
)
