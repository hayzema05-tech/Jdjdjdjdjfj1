from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import InlineKeyboardMarkup
from config import PRODUCTS, SUPPORT_BOT_USERNAME


def main_menu_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🛒 Купить Софт", callback_data="menu:buy")
    b.button(text="❓ FAQ", callback_data="menu:faq")
    b.button(text="👤 Профиль", callback_data="menu:profile")
    if SUPPORT_BOT_USERNAME:
        b.button(text="💬 Обратная связь", url=f"https://t.me/{SUPPORT_BOT_USERNAME}")
    else:
        b.button(text="💬 Обратная связь", callback_data="menu:support_soon")
    b.adjust(1)
    return b.as_markup()


def back_to_menu_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="⬅️ В меню", callback_data="menu:root")
    return b.as_markup()


def products_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for p in PRODUCTS:
        b.button(text=f"{p['title']} — {p['price_rub']}₽", callback_data=f"product:{p['id']}")
    b.button(text="⬅️ В меню", callback_data="menu:root")
    b.adjust(1)
    return b.as_markup()


def payment_methods_kb(product_id: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="💎 CryptoBot", callback_data=f"pay:crypto:{product_id}")
    b.button(text="💳 Банковская карта", callback_data=f"pay:card:{product_id}")
    b.button(text="⬅️ Назад", callback_data="menu:buy")
    b.adjust(1)
    return b.as_markup()


def card_paid_kb(purchase_id: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="✅ Я оплатил(а)", callback_data=f"cardpaid:{purchase_id}")
    b.button(text="⬅️ Отмена", callback_data="menu:buy")
    b.adjust(1)
    return b.as_markup()


def admin_confirm_kb(purchase_id: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="✅ Подтвердить", callback_data=f"admin_confirm:{purchase_id}")
    b.button(text="❌ Отклонить", callback_data=f"admin_reject:{purchase_id}")
    b.adjust(2)
    return b.as_markup()


def admin_panel_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="📢 Рассылка", callback_data="admin:broadcast")
    b.button(text="📊 Статистика", callback_data="admin:stats")
    b.adjust(1)
    return b.as_markup()
