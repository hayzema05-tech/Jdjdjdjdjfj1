from aiogram import Router, F
from aiogram.filters import CommandStart, CommandObject
from aiogram.types import Message, CallbackQuery

import database as db
from config import FAQ_TEXT, ADMIN_IDS
from keyboards import main_menu_kb, back_to_menu_kb, products_kb

router = Router()


def _extract_source(command: CommandObject) -> str:
    """/start promo_instagram -> source = 'promo_instagram'; /start без параметра -> 'direct'."""
    if command.args:
        return command.args.strip()
    return "direct"


@router.message(CommandStart())
async def cmd_start(message: Message, command: CommandObject):
    source = _extract_source(command)
    is_new = await db.add_user(
        user_id=message.from_user.id,
        username=message.from_user.username or "",
        full_name=message.from_user.full_name,
        source=source,
    )

    text = (
        f"👋 Привет, {message.from_user.first_name}!\n\n"
        "Добро пожаловать в магазин приватных ключей для Standoff 2.\n"
        "Выберите раздел ниже 👇"
    )
    await message.answer(text, reply_markup=main_menu_kb())

    if is_new:
        for admin_id in ADMIN_IDS:
            try:
                await message.bot.send_message(
                    admin_id,
                    f"🆕 Новый пользователь: {message.from_user.full_name} "
                    f"(@{message.from_user.username or '-'}, id {message.from_user.id})\n"
                    f"Источник: {source}",
                )
            except Exception:
                pass


@router.callback_query(F.data == "menu:root")
async def cb_menu_root(call: CallbackQuery):
    await call.message.edit_text(
        "Главное меню. Выберите раздел 👇", reply_markup=main_menu_kb()
    )
    await call.answer()


@router.callback_query(F.data == "menu:faq")
async def cb_faq(call: CallbackQuery):
    await call.message.edit_text(FAQ_TEXT, reply_markup=back_to_menu_kb())
    await call.answer()


@router.callback_query(F.data == "menu:profile")
async def cb_profile(call: CallbackQuery):
    user = await db.get_user(call.from_user.id)
    if user is None:
        await call.answer("Профиль не найден, введите /start", show_alert=True)
        return

    text = (
        "👤 <b>Ваш профиль</b>\n\n"
        f"ID: <code>{user['user_id']}</code>\n"
        f"Имя: {user['full_name']}\n"
        f"Username: @{user['username'] or '-'}\n"
        f"Дата регистрации: {user['reg_date'][:10]}\n"
        f"Источник перехода: {user['source']}"
    )
    await call.message.edit_text(text, reply_markup=back_to_menu_kb())
    await call.answer()


@router.callback_query(F.data == "menu:buy")
async def cb_buy(call: CallbackQuery):
    await call.message.edit_text(
        "🛒 Выберите товар:", reply_markup=products_kb()
    )
    await call.answer()


@router.callback_query(F.data == "menu:support_soon")
async def cb_support_soon(call: CallbackQuery):
    await call.answer("Раздел поддержки скоро подключим 🙌", show_alert=True)
