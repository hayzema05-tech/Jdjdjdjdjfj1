import aiohttp
from aiogram import Router, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

import database as db
from config import (
    PRODUCTS,
    CARD_NUMBER,
    CARD_HOLDER,
    CARD_BANK,
    CRYPTOBOT_TOKEN,
    PAYMENTS_CHAT_ID,
)
from keyboards import payment_methods_kb, card_paid_kb, admin_confirm_kb, back_to_menu_kb

router = Router()


class ReceiptState(StatesGroup):
    waiting_receipt = State()


def get_product(product_id: str):
    return next((p for p in PRODUCTS if p["id"] == product_id), None)


# ---------------------------------------------------------------------------
# Выбор товара -> выбор способа оплаты
# ---------------------------------------------------------------------------
@router.callback_query(F.data.startswith("product:"))
async def cb_product(call: CallbackQuery):
    product_id = call.data.split(":", 1)[1]
    product = get_product(product_id)
    if not product:
        await call.answer("Товар не найден", show_alert=True)
        return

    text = (
        f"<b>{product['title']}</b>\n\n"
        f"Цена: {product['price_rub']}₽ / {product['price_usdt']} USDT\n\n"
        "Выберите способ оплаты:"
    )
    await call.message.edit_text(text, reply_markup=payment_methods_kb(product_id))
    await call.answer()


# ---------------------------------------------------------------------------
# CryptoBot (Crypto Pay API)
# ---------------------------------------------------------------------------
CRYPTOPAY_API = "https://pay.crypt.bot/api"


@router.callback_query(F.data.startswith("pay:crypto:"))
async def cb_pay_crypto(call: CallbackQuery):
    product_id = call.data.split(":", 2)[2]
    product = get_product(product_id)
    if not product:
        await call.answer("Товар не найден", show_alert=True)
        return

    if not CRYPTOBOT_TOKEN:
        await call.answer(
            "Оплата криптой временно недоступна, попробуйте другой способ", show_alert=True
        )
        return

    async with aiohttp.ClientSession() as session:
        async with session.post(
            f"{CRYPTOPAY_API}/createInvoice",
            headers={"Crypto-Pay-API-Token": CRYPTOBOT_TOKEN},
            json={
                "asset": "USDT",
                "amount": str(product["price_usdt"]),
                "description": product["title"],
                "payload": f"{call.from_user.id}:{product_id}",
            },
        ) as resp:
            data = await resp.json()

    if not data.get("ok"):
        await call.answer("Не удалось создать счёт, попробуйте позже", show_alert=True)
        return

    invoice = data["result"]
    purchase_id = await db.create_purchase(
        user_id=call.from_user.id,
        product_id=product_id,
        product_title=product["title"],
        method="crypto",
        amount=f"{product['price_usdt']} USDT",
    )

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    b = InlineKeyboardBuilder()
    b.button(text="💳 Оплатить в CryptoBot", url=invoice["pay_url"])
    b.button(text="🔄 Я оплатил, проверить", callback_data=f"cryptocheck:{invoice['invoice_id']}:{purchase_id}")
    b.adjust(1)

    await call.message.edit_text(
        f"Счёт на {product['price_usdt']} USDT создан.\nОплатите по кнопке ниже, затем нажмите «Проверить».",
        reply_markup=b.as_markup(),
    )
    await call.answer()


@router.callback_query(F.data.startswith("cryptocheck:"))
async def cb_crypto_check(call: CallbackQuery):
    _, invoice_id, purchase_id = call.data.split(":")

    async with aiohttp.ClientSession() as session:
        async with session.get(
            f"{CRYPTOPAY_API}/getInvoices",
            headers={"Crypto-Pay-API-Token": CRYPTOBOT_TOKEN},
            params={"invoice_ids": invoice_id},
        ) as resp:
            data = await resp.json()

    items = data.get("result", {}).get("items", [])
    if not items:
        await call.answer("Счёт не найден", show_alert=True)
        return

    status = items[0]["status"]
    if status == "paid":
        purchase = await db.get_purchase(int(purchase_id))
        product = get_product(purchase["product_id"])
        await db.set_purchase_status(int(purchase_id), "confirmed")
        await db.credit_referral(call.from_user.id, product["price_rub"], REFERRAL_PERCENT)
        await call.message.edit_text(f"✅ Оплата получена!\n\n{product['delivery']}")
    else:
        await call.answer("Оплата пока не поступила", show_alert=True)


# ---------------------------------------------------------------------------
# Оплата картой -> пересылка чека -> подтверждение админом
# ---------------------------------------------------------------------------
@router.callback_query(F.data.startswith("pay:card:"))
async def cb_pay_card(call: CallbackQuery, state: FSMContext):
    product_id = call.data.split(":", 2)[2]
    product = get_product(product_id)
    if not product:
        await call.answer("Товар не найден", show_alert=True)
        return

    purchase_id = await db.create_purchase(
        user_id=call.from_user.id,
        product_id=product_id,
        product_title=product["title"],
        method="card",
        amount=f"{product['price_rub']} RUB",
    )

    text = (
        f"💳 <b>Оплата картой</b>\n\n"
        f"Сумма: <b>{product['price_rub']}₽</b>\n"
        f"Номер карты: <code>{CARD_NUMBER}</code>\n"
        f"Получатель: {CARD_HOLDER}\n"
        f"Банк: {CARD_BANK}\n\n"
        "После оплаты нажмите кнопку «Я оплатил(а)»."
    )
    await call.message.edit_text(text, reply_markup=card_paid_kb(purchase_id))
    await call.answer()


@router.callback_query(F.data.startswith("cardpaid:"))
async def cb_card_paid(call: CallbackQuery, state: FSMContext):
    purchase_id = int(call.data.split(":", 1)[1])
    await state.update_data(purchase_id=purchase_id)
    await state.set_state(ReceiptState.waiting_receipt)

    await call.message.edit_text(
        "📎 Отправьте, пожалуйста, скриншот или перешлите чек об оплате в этот чат для подтверждения транзакции.",
        reply_markup=back_to_menu_kb(),
    )
    await call.answer()


@router.message(ReceiptState.waiting_receipt, F.photo | F.document)
async def receive_receipt(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    purchase_id = data.get("purchase_id")
    if purchase_id is None:
        await message.answer("Не найдена активная заявка, начните заново через /start")
        await state.clear()
        return

    file_id = message.photo[-1].file_id if message.photo else message.document.file_id
    await db.attach_receipt(purchase_id, file_id)

    purchase = await db.get_purchase(purchase_id)

    caption = (
        f"🧾 Новый чек на подтверждение\n\n"
        f"Заявка №{purchase_id}\n"
        f"Товар: {purchase['product_title']}\n"
        f"Сумма: {purchase['amount']}\n"
        f"Пользователь: {message.from_user.full_name} (@{message.from_user.username or '-'}, "
        f"id {message.from_user.id})"
    )

    if message.photo:
        await bot.send_photo(
            PAYMENTS_CHAT_ID, file_id, caption=caption, reply_markup=admin_confirm_kb(purchase_id)
        )
    else:
        await bot.send_document(
            PAYMENTS_CHAT_ID, file_id, caption=caption, reply_markup=admin_confirm_kb(purchase_id)
        )

    await message.answer(
        "✅ Чек получен и отправлен на проверку. Обычно подтверждение занимает до 15 минут."
    )
    await state.clear()


@router.message(ReceiptState.waiting_receipt)
async def receipt_wrong_type(message: Message):
    await message.answer("Пожалуйста, отправьте чек как фото или файл (документ).")
