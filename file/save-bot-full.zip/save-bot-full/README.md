# save-bot

Telegram-бот для бизнес-аккаунтов: оповещает об удалённых/изменённых сообщениях и умеет скачивать одноразовые медиа. Плюс реферальная программа и платная подписка (CryptoBot / СБП / Telegram Stars) — подробности в `REFERRAL_PAYMENTS_README.md`.

## Запуск

1. Установите [Bun](https://bun.sh)
2. `bun install`
3. Скопируйте `.env.example` → `.env` и заполните значения (минимум `TELEGRAM_API_KEY`)
4. `bun run start`

## Структура

```
src/
  index.ts              — точка входа
  database.ts            — sqlite (настройки, доступ, рефералы, платежи)
  types.ts                — общие типы
  config/plans.ts         — тарифы подписки
  services/
    cryptobot.ts           — интеграция CryptoBot
    yookassa.ts             — интеграция ЮKassa (СБП)
  usecases/
    start.command.ts        — /start, обработка реферальной ссылки
    settings.command.ts     — /settings
    subscribe.command.ts    — /subscribe, оплата
    referral.command.ts     — /referral
    stars.payment.ts        — подтверждение оплаты Telegram Stars
    recieve.message.ts      — сохранение одноразовых медиа
    delete.message.ts       — уведомления об удалении
    edit.message.ts         — уведомления об изменении
  utils/text.ts            — вспомогательные функции
```

## Важно перед продакшеном

- Файл `src/utils/text.ts` реконструирован (в присланных вами файлах его не было). Если у вас уже есть оригинальный — используйте его вместо этого.
- Проверьте цены тарифов в `src/config/plans.ts`.
- Для СБП через ЮKassa нужна регистрация ИП/самозанятого/ООО — см. `REFERRAL_PAYMENTS_README.md`.
