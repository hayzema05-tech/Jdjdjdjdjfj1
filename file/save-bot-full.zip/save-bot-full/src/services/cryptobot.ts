// CryptoBot (@CryptoBot / @send) invoicing.
// Docs: https://help.crypt.bot/crypto-pay-api
// Get an API token from @CryptoBot -> Crypto Pay -> Create App.

const CRYPTOBOT_API_BASE =
  process.env.CRYPTOBOT_TESTNET === "true"
    ? "https://testnet-pay.crypt.bot/api"
    : "https://pay.crypt.bot/api";

type CryptoBotInvoice = {
  invoice_id: number;
  status: "active" | "paid" | "expired";
  pay_url: string;
  amount: string;
  asset: string;
};

function getToken(): string {
  const token = process.env.CRYPTOBOT_API_TOKEN;
  if (!token) {
    throw new Error("CRYPTOBOT_API_TOKEN is not set");
  }
  return token;
}

async function callApi<T>(method: string, params: Record<string, unknown>): Promise<T> {
  const res = await fetch(`${CRYPTOBOT_API_BASE}/${method}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Crypto-Pay-API-Token": getToken(),
    },
    body: JSON.stringify(params),
  });

  const json = await res.json();
  if (!json.ok) {
    throw new Error(`CryptoBot API error: ${JSON.stringify(json)}`);
  }
  return json.result as T;
}

export async function createCryptoBotInvoice(params: {
  amountUsdt: number;
  description: string;
  payload: string; // e.g. `payment:<paymentId>`
}): Promise<{ invoiceId: string; payUrl: string }> {
  const result = await callApi<CryptoBotInvoice>("createInvoice", {
    asset: "USDT",
    amount: params.amountUsdt.toString(),
    description: params.description,
    payload: params.payload,
    // Bot will poll status via "check" button, so no webhook URL is required.
  });

  return { invoiceId: String(result.invoice_id), payUrl: result.pay_url };
}

export async function getCryptoBotInvoiceStatus(
  invoiceId: string
): Promise<"active" | "paid" | "expired" | "unknown"> {
  const result = await callApi<{ items: CryptoBotInvoice[] }>("getInvoices", {
    invoice_ids: invoiceId,
  });

  const invoice = result.items?.[0];
  return invoice?.status ?? "unknown";
}
