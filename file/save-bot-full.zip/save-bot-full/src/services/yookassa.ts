// YooKassa (ЮKassa) payments via SBP (Система быстрых платежей).
// Docs: https://yookassa.ru/developers/api
// Requires a registered shop (self-employed / IP / ООО) at yookassa.ru.
// Get shopId and secretKey from your YooKassa dashboard.

const YOOKASSA_API_BASE = "https://api.yookassa.ru/v3";

function getAuthHeader(): string {
  const shopId = process.env.YOOKASSA_SHOP_ID;
  const secretKey = process.env.YOOKASSA_SECRET_KEY;
  if (!shopId || !secretKey) {
    throw new Error("YOOKASSA_SHOP_ID / YOOKASSA_SECRET_KEY are not set");
  }
  return "Basic " + Buffer.from(`${shopId}:${secretKey}`).toString("base64");
}

type YooKassaPayment = {
  id: string;
  status: "pending" | "waiting_for_capture" | "succeeded" | "canceled";
  confirmation?: { confirmation_url: string };
};

export async function createSbpPayment(params: {
  amountRub: number;
  description: string;
  returnUrl: string;
  idempotenceKey: string;
}): Promise<{ paymentId: string; confirmationUrl: string }> {
  const res = await fetch(`${YOOKASSA_API_BASE}/payments`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": getAuthHeader(),
      "Idempotence-Key": params.idempotenceKey,
    },
    body: JSON.stringify({
      amount: { value: params.amountRub.toFixed(2), currency: "RUB" },
      payment_method_data: { type: "sbp" },
      confirmation: { type: "redirect", return_url: params.returnUrl },
      description: params.description,
      capture: true,
    }),
  });

  const json = (await res.json()) as YooKassaPayment;
  if (!res.ok) {
    throw new Error(`YooKassa API error: ${JSON.stringify(json)}`);
  }

  return {
    paymentId: json.id,
    confirmationUrl: json.confirmation?.confirmation_url ?? "",
  };
}

export async function getSbpPaymentStatus(
  paymentId: string
): Promise<"pending" | "waiting_for_capture" | "succeeded" | "canceled" | "unknown"> {
  const res = await fetch(`${YOOKASSA_API_BASE}/payments/${paymentId}`, {
    method: "GET",
    headers: { "Authorization": getAuthHeader() },
  });

  if (!res.ok) return "unknown";
  const json = (await res.json()) as YooKassaPayment;
  return json.status ?? "unknown";
}
