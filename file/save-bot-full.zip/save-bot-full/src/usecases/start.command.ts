import { Composer } from "grammy";
import type { MyContext } from "../types";
import { REFERRAL_BONUS_DAYS } from "../config/plans";

const startCommand = new Composer<MyContext>();

startCommand.command("start", async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;

  // Deep-link payload, e.g. t.me/<bot>?start=ref_123456789
  const payload = ctx.match?.toString().trim() ?? "";
  let referredBy: number | null = null;
  if (payload.startsWith("ref_")) {
    const parsed = Number(payload.slice(4));
    if (Number.isInteger(parsed) && parsed > 0) {
      referredBy = parsed;
    }
  }

  const { isNew } = ctx.db.ensureUser(
    userId,
    ctx.from.username ?? null,
    referredBy
  );

  // Grant the referrer a bonus if this new user already has Telegram Premium.
  // ctx.from.is_premium is set directly by the Bot API on the User object.
  let referralBonusMessage = "";
  if (isNew && ctx.from.is_premium) {
    const referrerId = ctx.db.tryGrantReferralBonus(userId, REFERRAL_BONUS_DAYS);
    if (referrerId) {
      try {
        await ctx.api.sendMessage(
          referrerId,
          `🎉 По твоей реферальной ссылке присоединился пользователь с Telegram Premium!\nТебе начислено +${REFERRAL_BONUS_DAYS} дня доступа.`
        );
      } catch {
        // referrer may have blocked the bot — ignore
      }
    }
  } else if (isNew && referredBy) {
    referralBonusMessage =
      "\n\nЗаметка: бонус за реферала начисляется, только если у приглашённого пользователя активен Telegram Premium на момент запуска бота.";
  }

  const hasAccess = ctx.db.hasAccess(userId);
  const accessStatus = hasAccess
    ? "✅ У тебя есть активный доступ. Используй /subscribe чтобы продлить."
    : "🔒 У тебя нет активного доступа. Оформи подписку через /subscribe или пригласи друга с Telegram Premium через /referral — это +3 дня бесплатно.";

  const message = `Привет!
Этот бот умеет сохранять одноразовые медиа и уведомлять об изменении/удалении сообщений.

Для того, чтобы сохранить одноразовое медиа просто ответь на него каким-нибудь сообщением. 
  
Для начала работы добавь бота в бизнес-боты
(Настройки -> Telegram для бизнеса -> Чат-боты -> @${ctx.me.username}).

${accessStatus}${referralBonusMessage}`;

  await ctx.reply(message);
});

export default startCommand;
