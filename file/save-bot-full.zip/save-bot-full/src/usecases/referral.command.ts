import { Composer } from "grammy";
import type { MyContext } from "../types";
import { REFERRAL_BONUS_DAYS } from "../config/plans";

const referralCommand = new Composer<MyContext>();

referralCommand.command("referral", async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;

  ctx.db.ensureUser(userId, ctx.from.username ?? null);

  const stats = ctx.db.getReferralStats(userId);
  const link = `https://t.me/${ctx.me.username}?start=ref_${userId}`;

  const message = `<b>Реферальная программа</b>

За каждого друга, который запустит бота по твоей ссылке и у которого активен <b>Telegram Premium</b>, тебе начисляется <b>+${REFERRAL_BONUS_DAYS} дня</b> доступа.

Твоя ссылка:
<code>${link}</code>

Приглашено всего: <b>${stats.total}</b>
Принесли бонус (Premium): <b>${stats.rewarded}</b>`;

  await ctx.reply(message, { parse_mode: "HTML" });
});

export default referralCommand;
