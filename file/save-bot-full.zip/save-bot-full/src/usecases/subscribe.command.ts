import { Composer, InlineKeyboard } from "grammy";
import type { MyContext } from "../types";
import {
  PLAN_ORDER,
  PLANS,
  getPlan,
  providerLabel,
  type PaymentProvider,
  type PlanId,
} from "../config/plans";
import { createCryptoBotInvoice, getCryptoBotInvoiceStatus } from "../services/cryptobot";
import { createSbpPayment, getSbpPaymentStatus } from "../services/yookassa";

const subscribeCommand = new Composer<MyContext>();

const PLAN_PREFIX = "sub:plan:";
const PAY_PREFIX = "sub:pay:";
const CHECK_PREFIX = "sub:check:";

function plansKeyboard() {
  const kb = new InlineKeyboard();
  for (const planId of PLAN_ORDER) {
    const plan = PLANS[planId];
    kb.text(`${plan.label} — ${plan.priceRub}₽`, `${PLAN_PREFIX}${planId}`).row();
  }
  return kb;
}

function providersKeyboard(planId: PlanId) {
  const plan = PLANS[planId];
  return new InlineKeyboard()
    .text(`💎 CryptoBot — ${plan.priceUsdt} USDT`, `${PAY_PREFIX}${planId}:cryptobot`)
    .row()
    .text(`🏦 СБП — ${plan.priceRub}₽`, `${PAY_PREFIX}${planId}:sbp`)
    .row()
    .text(`⭐ Telegram Stars — ${plan.priceStars}`, `${PAY_PREFIX}${planId}:stars`)
    .row()
    .text("‹ Назад", "sub:back");
}

subscribeCommand.command("subscribe", async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;
  ctx.db.ensureUser(userId, ctx.from.username ?? null);

  const hasAccess = ctx.db.hasAccess(userId);
  const user = ctx.db.getUser(userId);
  const statusLine =
    hasAccess && user?.accessUntil
      ? `Текущий доступ активен до ${new Date(user.accessUntil * 1000).toLocaleDateString("ru-RU")}.\n\n`
      : "";

  await ctx.reply(`${statusLine}Выбери срок подписки:`, {
    reply_markup: plansKeyboard(),
  });
});

subscribeCommand.callbackQuery("sub:back", async (ctx) => {
  await ctx.answerCallbackQuery();
  await ctx.editMessageText("Выбери срок подписки:", {
    reply_markup: plansKeyboard(),
  });
});

subscribeCommand.callbackQuery(new RegExp(`^${PLAN_PREFIX}(1m|3m|6m|1y)$`), async (ctx) => {
  const planId = ctx.match[1] as PlanId;
  const plan = getPlan(planId);
  if (!plan) return ctx.answerCallbackQuery();

  await ctx.answerCallbackQuery();
  await ctx.editMessageText(
    `Тариф: <b>${plan.label}</b>\nВыбери способ оплаты:`,
    { parse_mode: "HTML", reply_markup: providersKeyboard(planId) }
  );
});

subscribeCommand.callbackQuery(
  new RegExp(`^${PAY_PREFIX}(1m|3m|6m|1y):(cryptobot|sbp|stars)$`),
  async (ctx) => {
    const userId = ctx.from?.id;
    if (!userId) return;

    const planId = ctx.match[1] as PlanId;
    const provider = ctx.match[2] as PaymentProvider;
    const plan = getPlan(planId);
    if (!plan) return ctx.answerCallbackQuery();

    await ctx.answerCallbackQuery();

    if (provider === "stars") {
      // Telegram Stars uses a native invoice, not a redirect link.
      const paymentId = ctx.db.createPayment({
        userId,
        provider: "stars",
        plan: planId,
        amount: String(plan.priceStars),
        currency: "XTR",
      });

      await ctx.api.sendInvoice(
        userId,
        `Подписка: ${plan.label}`,
        `Доступ к боту на ${plan.label}`,
        `payment:${paymentId}`,
        "", // provider_token is empty for Telegram Stars
        "XTR",
        [{ label: plan.label, amount: plan.priceStars }]
      );
      return;
    }

    try {
      if (provider === "cryptobot") {
        const paymentId = ctx.db.createPayment({
          userId,
          provider: "cryptobot",
          plan: planId,
          amount: String(plan.priceUsdt),
          currency: "USDT",
        });

        const invoice = await createCryptoBotInvoice({
          amountUsdt: plan.priceUsdt,
          description: `Подписка ${plan.label}`,
          payload: `payment:${paymentId}`,
        });
        ctx.db.setPaymentExternalId(paymentId, invoice.invoiceId);

        const kb = new InlineKeyboard()
          .url("💳 Оплатить", invoice.payUrl)
          .row()
          .text("✅ Я оплатил, проверить", `${CHECK_PREFIX}${paymentId}`);

        await ctx.editMessageText(
          `Тариф: <b>${plan.label}</b>\nСумма: ${plan.priceUsdt} USDT\n\nОплати по кнопке ниже, затем нажми "Проверить".`,
          { parse_mode: "HTML", reply_markup: kb }
        );
      }

      if (provider === "sbp") {
        const paymentId = ctx.db.createPayment({
          userId,
          provider: "sbp",
          plan: planId,
          amount: String(plan.priceRub),
          currency: "RUB",
        });

        const payment = await createSbpPayment({
          amountRub: plan.priceRub,
          description: `Подписка ${plan.label}`,
          returnUrl: `https://t.me/${ctx.me.username}`,
          idempotenceKey: `payment-${paymentId}`,
        });
        ctx.db.setPaymentExternalId(paymentId, payment.paymentId);

        const kb = new InlineKeyboard()
          .url("💳 Оплатить через СБП", payment.confirmationUrl)
          .row()
          .text("✅ Я оплатил, проверить", `${CHECK_PREFIX}${paymentId}`);

        await ctx.editMessageText(
          `Тариф: <b>${plan.label}</b>\nСумма: ${plan.priceRub}₽\n\nОплати по кнопке ниже, затем нажми "Проверить".`,
          { parse_mode: "HTML", reply_markup: kb }
        );
      }
    } catch (err) {
      console.error(`Failed to create ${provider} invoice:`, err);
      await ctx.reply(
        "Не получилось создать счёт на оплату. Попробуй позже или выбери другой способ оплаты."
      );
    }
  }
);

subscribeCommand.callbackQuery(new RegExp(`^${CHECK_PREFIX}(\\d+)$`), async (ctx) => {
  const paymentId = Number(ctx.match[1]);
  const payment = ctx.db.getPayment(paymentId);

  if (!payment) {
    return ctx.answerCallbackQuery({ text: "Платёж не найден.", show_alert: true });
  }

  if (payment.status === "paid") {
    return ctx.answerCallbackQuery({ text: "Этот платёж уже зачислен ✅", show_alert: true });
  }

  let isPaid = false;

  try {
    if (payment.provider === "cryptobot" && payment.externalId) {
      const status = await getCryptoBotInvoiceStatus(payment.externalId);
      isPaid = status === "paid";
    }

    if (payment.provider === "sbp" && payment.externalId) {
      const status = await getSbpPaymentStatus(payment.externalId);
      isPaid = status === "succeeded";
    }
  } catch (err) {
    console.error("Failed to check payment status:", err);
    return ctx.answerCallbackQuery({
      text: "Не получилось проверить оплату, попробуй чуть позже.",
      show_alert: true,
    });
  }

  if (!isPaid) {
    return ctx.answerCallbackQuery({
      text: "Оплата пока не найдена. Если ты уже оплатил — подожди немного и попробуй снова.",
      show_alert: true,
    });
  }

  const plan = getPlan(payment.plan);
  ctx.db.markPaymentPaid(paymentId);
  const newAccessUntil = ctx.db.grantAccessDays(payment.userId, plan?.days ?? 0);

  await ctx.answerCallbackQuery({ text: "Оплата подтверждена! ✅" });
  await ctx.editMessageText(
    `✅ Оплата подтверждена!\nДоступ активен до <b>${new Date(
      newAccessUntil * 1000
    ).toLocaleDateString("ru-RU")}</b>.`,
    { parse_mode: "HTML" }
  );
});

export { providerLabel };
export default subscribeCommand;
