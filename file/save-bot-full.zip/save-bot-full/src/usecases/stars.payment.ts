import { Composer } from "grammy";
import type { MyContext } from "../types";
import { getPlan } from "../config/plans";

export const starsPaymentHandler = new Composer<MyContext>();

starsPaymentHandler.on("pre_checkout_query", async (ctx) => {
  // Always approve — validation already happened when the invoice was created.
  await ctx.answerPreCheckoutQuery(true);
});

starsPaymentHandler.on("message:successful_payment", async (ctx) => {
  const payload = ctx.msg.successful_payment.invoice_payload;
  const userId = ctx.from.id;

  const match = payload.match(/^payment:(\d+)$/);
  if (!match) return;

  const paymentId = Number(match[1]);
  const payment = ctx.db.getPayment(paymentId);
  if (!payment || payment.status === "paid") return;

  const plan = getPlan(payment.plan);
  ctx.db.markPaymentPaid(paymentId);
  const newAccessUntil = ctx.db.grantAccessDays(userId, plan?.days ?? 0);

  await ctx.reply(
    `✅ Оплата через Telegram Stars получена!\nДоступ активен до <b>${new Date(
      newAccessUntil * 1000
    ).toLocaleDateString("ru-RU")}</b>.`,
    { parse_mode: "HTML" }
  );
});
