export type PlanId = "1m" | "3m" | "6m" | "1y";
export type PaymentProvider = "cryptobot" | "sbp" | "stars";

export type Plan = {
  id: PlanId;
  label: string;
  days: number;
  priceRub: number; // used for SBP (YooKassa), RUB
  priceUsdt: number; // used for CryptoBot, USDT
  priceStars: number; // used for Telegram Stars, XTR
};

// NOTE: adjust prices to whatever you actually want to charge.
// Stars price is roughly priceUsdt / 0.013 (Telegram's approx XTR->USD rate), rounded.
export const PLANS: Record<PlanId, Plan> = {
  "1m": { id: "1m", label: "1 месяц", days: 30, priceRub: 199, priceUsdt: 2.5, priceStars: 150 },
  "3m": { id: "3m", label: "3 месяца", days: 90, priceRub: 499, priceUsdt: 6, priceStars: 375 },
  "6m": { id: "6m", label: "6 месяцев", days: 180, priceRub: 899, priceUsdt: 11, priceStars: 675 },
  "1y": { id: "1y", label: "1 год", days: 365, priceRub: 1499, priceUsdt: 18, priceStars: 1125 },
};

export const PLAN_ORDER: PlanId[] = ["1m", "3m", "6m", "1y"];

export const REFERRAL_BONUS_DAYS = 3;

export function getPlan(planId: string): Plan | undefined {
  return PLANS[planId as PlanId];
}

export function providerLabel(provider: PaymentProvider): string {
  switch (provider) {
    case "cryptobot":
      return "CryptoBot (крипта)";
    case "sbp":
      return "СБП (карта/банк)";
    case "stars":
      return "Telegram Stars";
  }
}
