// NOTE: this file was not provided during the referral/payments update,
// so it's a standard reconstruction. If your original src/utils/text.ts
// differs, keep your original instead of this one.

export function escapeHtml(text: string | undefined | null): string {
  if (!text) return "";
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}
