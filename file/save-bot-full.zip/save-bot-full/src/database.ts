import { Database as BunDatabase } from "bun:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import type { Settings } from "./types";
import type { PaymentProvider, PlanId } from "./config/plans";

export type PaymentStatus = "pending" | "paid" | "failed" | "expired";

export type UserRecord = {
  userId: number;
  username: string | null;
  accessUntil: number | null; // unix seconds, null = never had access
  referredBy: number | null;
  referralBonusGranted: boolean;
  createdAt: number;
};

export type PaymentRecord = {
  id: number;
  userId: number;
  provider: PaymentProvider;
  plan: PlanId;
  amount: string;
  currency: string;
  externalId: string | null;
  status: PaymentStatus;
  createdAt: number;
  paidAt: number | null;
};

export class Database {
  private db: BunDatabase;

  constructor(filename: string = "savebot.sqlite") {
    const dir = dirname(filename);
    if (dir && dir !== ".") {
      mkdirSync(dir, { recursive: true });
    }

    this.db = new BunDatabase(filename, { create: true });
    this.init();
  }

  private init() {
    this.db.exec("PRAGMA journal_mode = WAL;");

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS settings (
        user_id INTEGER PRIMARY KEY,
        send_yours_deleted INTEGER NOT NULL DEFAULT 1,
        send_yours_edited INTEGER NOT NULL DEFAULT 1,
        notify_on_deleted INTEGER NOT NULL DEFAULT 1,
        notify_on_edited INTEGER NOT NULL DEFAULT 1
      );
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        access_until INTEGER,
        referred_by INTEGER,
        referral_bonus_granted INTEGER NOT NULL DEFAULT 0,
        created_at INTEGER NOT NULL
      );
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        provider TEXT NOT NULL,
        plan TEXT NOT NULL,
        amount TEXT NOT NULL,
        currency TEXT NOT NULL,
        external_id TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        created_at INTEGER NOT NULL,
        paid_at INTEGER
      );
    `);

    this.db.exec(
      `CREATE INDEX IF NOT EXISTS idx_payments_user ON payments(user_id);`
    );
    this.db.exec(
      `CREATE INDEX IF NOT EXISTS idx_users_referred_by ON users(referred_by);`
    );
  }

  // ---------- Settings (unchanged) ----------

  getSettings(userId: number): Settings {
    const query = this.db.query<Settings, { $user_id: number }>(`
      SELECT 
        send_yours_deleted as sendYoursDeleted,
        send_yours_edited as sendYoursEdited,
        notify_on_deleted as notifyOnDeleted,
        notify_on_edited as notifyOnEdited
      FROM settings 
      WHERE user_id = $user_id
    `);

    const result = query.get({ $user_id: userId });

    if (!result) {
      const defaults = this.getDefaultSettings();
      this.db
        .query(
          `
        INSERT INTO settings (user_id, send_yours_deleted, send_yours_edited, notify_on_deleted, notify_on_edited)
        VALUES ($user_id, $send_yours_deleted, $send_yours_edited, $notify_on_deleted, $notify_on_edited)
      `
        )
        .run({
          $user_id: userId,
          $send_yours_deleted: defaults.sendYoursDeleted ? 1 : 0,
          $send_yours_edited: defaults.sendYoursEdited ? 1 : 0,
          $notify_on_deleted: defaults.notifyOnDeleted ? 1 : 0,
          $notify_on_edited: defaults.notifyOnEdited ? 1 : 0,
        });
      return defaults;
    }

    return {
      sendYoursDeleted: Boolean(result.sendYoursDeleted),
      sendYoursEdited: Boolean(result.sendYoursEdited),
      notifyOnDeleted: Boolean(result.notifyOnDeleted),
      notifyOnEdited: Boolean(result.notifyOnEdited),
    };
  }

  updateSettings(userId: number, updates: Partial<Settings>): Settings {
    const current = this.getSettings(userId);
    const updated = { ...current, ...updates };

    this.db
      .query(
        `
      UPDATE settings 
      SET send_yours_deleted = $send_yours_deleted,
          send_yours_edited = $send_yours_edited,
          notify_on_deleted = $notify_on_deleted,
          notify_on_edited = $notify_on_edited
      WHERE user_id = $user_id
    `
      )
      .run({
        $user_id: userId,
        $send_yours_deleted: updated.sendYoursDeleted ? 1 : 0,
        $send_yours_edited: updated.sendYoursEdited ? 1 : 0,
        $notify_on_deleted: updated.notifyOnDeleted ? 1 : 0,
        $notify_on_edited: updated.notifyOnEdited ? 1 : 0,
      });

    return updated;
  }

  toggleSetting(
    userId: number,
    key: keyof Settings
  ): { newValue: boolean; settings: Settings } {
    const current = this.getSettings(userId);
    const newValue = !current[key];
    const updated = { ...current, [key]: newValue };

    this.updateSettings(userId, updated);

    return { newValue, settings: updated };
  }

  private getDefaultSettings(): Settings {
    return {
      sendYoursDeleted: true,
      sendYoursEdited: true,
      notifyOnDeleted: true,
      notifyOnEdited: true,
    };
  }

  // ---------- Users / access / referrals ----------

  private mapUserRow(row: any): UserRecord {
    return {
      userId: row.user_id,
      username: row.username,
      accessUntil: row.access_until,
      referredBy: row.referred_by,
      referralBonusGranted: Boolean(row.referral_bonus_granted),
      createdAt: row.created_at,
    };
  }

  getUser(userId: number): UserRecord | null {
    const row = this.db
      .query(`SELECT * FROM users WHERE user_id = $user_id`)
      .get({ $user_id: userId }) as any;
    return row ? this.mapUserRow(row) : null;
  }

  /**
   * Creates the user row if it doesn't exist yet.
   * Returns { user, isNew }. referredBy is only applied on first creation.
   */
  ensureUser(
    userId: number,
    username: string | null,
    referredBy: number | null = null
  ): { user: UserRecord; isNew: boolean } {
    const existing = this.getUser(userId);
    if (existing) {
      if (username && username !== existing.username) {
        this.db
          .query(`UPDATE users SET username = $username WHERE user_id = $user_id`)
          .run({ $user_id: userId, $username: username });
        existing.username = username;
      }
      return { user: existing, isNew: false };
    }

    const now = Math.floor(Date.now() / 1000);
    // A user can't refer themselves, and referrer must already exist.
    const validReferredBy =
      referredBy && referredBy !== userId && this.getUser(referredBy)
        ? referredBy
        : null;

    this.db
      .query(
        `INSERT INTO users (user_id, username, access_until, referred_by, referral_bonus_granted, created_at)
         VALUES ($user_id, $username, NULL, $referred_by, 0, $created_at)`
      )
      .run({
        $user_id: userId,
        $username: username,
        $referred_by: validReferredBy,
        $created_at: now,
      });

    return { user: this.getUser(userId)!, isNew: true };
  }

  hasAccess(userId: number): boolean {
    const user = this.getUser(userId);
    if (!user || !user.accessUntil) return false;
    return user.accessUntil > Math.floor(Date.now() / 1000);
  }

  /**
   * Extends access from max(now, currentAccessUntil) by `days`.
   * Returns the new access_until unix timestamp.
   */
  grantAccessDays(userId: number, days: number): number {
    const now = Math.floor(Date.now() / 1000);
    const user = this.getUser(userId);
    const base =
      user?.accessUntil && user.accessUntil > now ? user.accessUntil : now;
    const newAccessUntil = base + days * 86400;

    this.db
      .query(`UPDATE users SET access_until = $access_until WHERE user_id = $user_id`)
      .run({ $user_id: userId, $access_until: newAccessUntil });

    return newAccessUntil;
  }

  /**
   * Called when a referred user is confirmed to have Telegram Premium.
   * Grants REFERRAL_BONUS_DAYS to the referrer exactly once per referred user.
   * Returns the referrer id if a bonus was granted, otherwise null.
   */
  tryGrantReferralBonus(referredUserId: number, bonusDays: number): number | null {
    const referred = this.getUser(referredUserId);
    if (!referred || !referred.referredBy || referred.referralBonusGranted) {
      return null;
    }

    this.grantAccessDays(referred.referredBy, bonusDays);

    this.db
      .query(
        `UPDATE users SET referral_bonus_granted = 1 WHERE user_id = $user_id`
      )
      .run({ $user_id: referredUserId });

    return referred.referredBy;
  }

  getReferralStats(userId: number): { total: number; rewarded: number } {
    const total = this.db
      .query(`SELECT COUNT(*) as c FROM users WHERE referred_by = $user_id`)
      .get({ $user_id: userId }) as { c: number };
    const rewarded = this.db
      .query(
        `SELECT COUNT(*) as c FROM users WHERE referred_by = $user_id AND referral_bonus_granted = 1`
      )
      .get({ $user_id: userId }) as { c: number };

    return { total: total.c, rewarded: rewarded.c };
  }

  // ---------- Payments ----------

  createPayment(params: {
    userId: number;
    provider: PaymentProvider;
    plan: PlanId;
    amount: string;
    currency: string;
    externalId?: string | null;
  }): number {
    const now = Math.floor(Date.now() / 1000);
    const result = this.db
      .query(
        `INSERT INTO payments (user_id, provider, plan, amount, currency, external_id, status, created_at)
         VALUES ($user_id, $provider, $plan, $amount, $currency, $external_id, 'pending', $created_at)`
      )
      .run({
        $user_id: params.userId,
        $provider: params.provider,
        $plan: params.plan,
        $amount: params.amount,
        $currency: params.currency,
        $external_id: params.externalId ?? null,
        $created_at: now,
      });

    return Number(result.lastInsertRowid);
  }

  setPaymentExternalId(paymentId: number, externalId: string) {
    this.db
      .query(`UPDATE payments SET external_id = $external_id WHERE id = $id`)
      .run({ $id: paymentId, $external_id: externalId });
  }

  private mapPaymentRow(row: any): PaymentRecord {
    return {
      id: row.id,
      userId: row.user_id,
      provider: row.provider,
      plan: row.plan,
      amount: row.amount,
      currency: row.currency,
      externalId: row.external_id,
      status: row.status,
      createdAt: row.created_at,
      paidAt: row.paid_at,
    };
  }

  getPayment(paymentId: number): PaymentRecord | null {
    const row = this.db
      .query(`SELECT * FROM payments WHERE id = $id`)
      .get({ $id: paymentId }) as any;
    return row ? this.mapPaymentRow(row) : null;
  }

  markPaymentPaid(paymentId: number): PaymentRecord | null {
    const now = Math.floor(Date.now() / 1000);
    this.db
      .query(
        `UPDATE payments SET status = 'paid', paid_at = $paid_at WHERE id = $id AND status != 'paid'`
      )
      .run({ $id: paymentId, $paid_at: now });
    return this.getPayment(paymentId);
  }

  markPaymentFailed(paymentId: number) {
    this.db
      .query(`UPDATE payments SET status = 'failed' WHERE id = $id AND status = 'pending'`)
      .run({ $id: paymentId });
  }

  close() {
    this.db.close();
  }
}
